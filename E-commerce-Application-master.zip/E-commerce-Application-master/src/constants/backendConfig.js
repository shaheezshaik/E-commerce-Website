module.exports = {
  mysql: {
    prod: {
      host: "localhost",
      user: "root",
      password: "root",
      database: "Ecommercedb",
    },
  },
};
