# E-commerce-Application
This app will have the features of user account creation, can get the products, can list the categories and adding the products to the cart page and placing the orders.

## Dependencies
1. Express
2. bcrypt
3. body-parser
4. jsonwebtokens
5. mysql2

